const index = (req, res) => {
    res.render('index', { title: "Travlr Getaways"});
};

/* Module exports*/
module.exports = {
    index
}